This is a Clue game with AI. The person plays against five others who are all handled by the computer
To run this project make sure all the files are in the same folder and all the images except the background are in the ImagesGIF subfolder.
Then just run 'runWholeGame.py' to play